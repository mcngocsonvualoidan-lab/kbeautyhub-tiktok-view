# 🛍️ Kbeautyhub - TikTok View Giỏ Hàng & Shop PC (v2.0.3)

> **Developed by Son Designer • Kbeautyhub**  
> Tiện ích mở rộng Chrome Extension Manifest V3 xem trực tiếp thông tin sản phẩm, giá bán, link mua sắm TikTok Shop và tên Shop bán sản phẩm từ video có gắn giỏ hàng ngay trên máy tính (PC/Laptop).

---

## 🚀 LINK CÀI ĐẶT ONLINE TRỰC TIẾP (GITHUB)

- 📥 **Tải bản cài đặt nhanh (.ZIP):**  
  [**Tải Kbeautyhub-Tiktok-View-v2.0.3.zip**](https://github.com/mcngocsonvualoidan-lab/kbeautyhub-tiktok-view/releases/download/v2.0.3/Kbeautyhub-Tiktok-View-v2.0.3.zip)
- 🌐 **Repository GitHub:**  
  [https://github.com/mcngocsonvualoidan-lab/kbeautyhub-tiktok-view](https://github.com/mcngocsonvualoidan-lab/kbeautyhub-tiktok-view)

---

## 🔑 MẬT KHẨU SỬ DỤNG

| Loại tài khoản | Mật khẩu | Quyền hạn |
| :--- | :--- | :--- |
| **Khách (Guest)** | `guest2026` | Xem video, xem giỏ hàng, mở link shop, xem lịch sử cá nhân riêng tư |
| **Quản trị (Admin)** | `kbeautyhub` | Toàn quyền cấu hình, quản lý tất cả thiết bị online, xem lịch sử tổng hợp của tất cả các máy, đồng bộ Google Cloud |

---

## 🌟 TÍNH NĂNG NỔI BẬT TRÊN BẢN v2.0.3

1. **Khắc phục triệt để lỗi cuộn sang video thứ 2, thứ 3 có tiếng nhưng mất hình:**
   - Thuật toán định vị khung phát nhận diện theo toạ độ Viewport Overlap thực tế trên màn hình, không còn bị gắn nhầm vào thẻ video cũ đã cuộn khuất lên trên.
   - Nếu video đang phát bình thường trên PC (không bị TikTok chặn), tiện ích bảo toàn phát native mượt mà, không can thiệp ẩn video gây trắng màn hình.
   - Tự động gắn chính xác vào đúng khung video đang hiển thị trước mắt người dùng.
2. **Nhận diện Giỏ hàng tức thì khi cuộn trang:**
   - Quét DOM anchor theo thời gian thực (nhận diện các thẻ shop như `Rosaleen`, `TikTok Shop`), không cần phải ấn F5 tải lại trang.
3. **Nhận diện Tên Shop bán sản phẩm tức thì (100% không kẹt loading):**
   - Tự động bóc tách tên shop người bán (`shop_name`, `seller_name`, `brand_name`) từ dữ liệu TikTok.
   - Fallback thông minh sang Gian hàng Creator (`Author Nickname (@uniqueId)`) kèm nút `↗️ Vào Shop` mở trực tiếp gian hàng trên TikTok.
2. **Xem và phát video mượt mà trên PC:**
   - Không bị chặn bởi banner giỏ hàng của TikTok, giải mã trực tiếp luồng stream video.
3. **Bật / Tắt tiện ích (Master Switch) linh hoạt:**
   - Nút bật/tắt tiện ích lưu trạng thái vĩnh viễn vào bộ nhớ trình duyệt, không bị tự động bật lại sau khi ấn F5.
4. **Hệ thống phân quyền & Bảo mật:**
   - Màn hình khóa nhập mật khẩu khi cài đặt mới.
   - Lịch sử xem của mỗi tài khoản Guest hoàn toàn độc lập và riêng tư.
5. **Đồng bộ hóa Online Miễn Phí (Google Apps Script / Sheets):**
   - Không tốn chi phí server. Tự động ghi nhận thiết bị đăng nhập thời gian thực và lịch sử xem lên Google Sheet dành riêng cho Admin.
6. **Xuất báo cáo Excel / CSV chuẩn định dạng:**
   - Xuất dữ liệu video, sản phẩm, giá, tên shop ra file Excel/CSV chuẩn cột hàng, hỗ trợ tiếng Việt có dấu (UTF-8 with BOM).

---

## 💻 HƯỚNG DẪN CÀI ĐẶT NHANH TRÊN CHROME / CỐC CỐC / EDGE

### Cách 1: Cài đặt từ file Zip tải về (Được khuyên dùng)
1. Tải file [**Kbeautyhub-Tiktok-View-v1.9.6.zip**](https://github.com/mcngocsonvualoidan-lab/kbeautyhub-tiktok-view/raw/main/Kbeautyhub-Tiktok-View-v1.9.6.zip) về máy tính.
2. Giải nén file zip ra một thư mục (ví dụ: `kbeautyhub-tiktok-view`).
3. Mở trình duyệt và truy cập `chrome://extensions` (hoặc `coccoc://extensions` / `edge://extensions`).
4. Gạt công tắc **Chế độ dành cho nhà phát triển (Developer mode)** ở góc trên bên phải sang **BẬT (ON)**.
5. Nhấn nút **Tải tiện ích đã giải nén (Load unpacked)** và chọn thư mục vừa giải nén.
6. Nhấn vào biểu tượng tiện ích Kbeautyhub trên thanh công cụ, nhập mật khẩu `guest2026` (hoặc `kbeautyhub` cho Admin) để bắt đầu sử dụng!

### Cách 2: Cài đặt qua Git Clone
```bash
git clone https://github.com/mcngocsonvualoidan-lab/kbeautyhub-tiktok-view.git
```
Sau đó vào `chrome://extensions` chọn **Load unpacked** trỏ vào thư mục vừa clone.

---

## 👨‍💻 THÔNG TIN TÁC GIẢ & BẢN QUYỀN
- **Tác giả:** Son Designer • Kbeautyhub
- **Phiên bản:** 1.9.6 (Latest Stable)
- **Hỗ trợ:** Kbeautyhub Team
